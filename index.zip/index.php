<?php
session_start();
 ?>
 <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Material Design Bootstrap</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="include/header_style.css">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
</head>

<body style="">
<section class="container-fluid">
  <!--Main Navigation-->
<header>

  <nav class="navbar navbar-expand-lg z-depth-0 navbar-dark  mx-auto" style="height: 20px;background: black;">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item ">
          <a class="nav-link" href="#">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Features</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Donate</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Write With us</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#">Queries</a>
        </li>
      </ul>
      <ul class="navbar-nav nav-flex-icons">
        <li class="nav-item">
          <a class="nav-link"><i class="fab fa-facebook-f"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link"><i class="fab fa-twitter"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link"><i class="fab fa-instagram"></i></a>
        </li>
      </ul>
    </div>
  </nav>

</header>
<!--Main Navigation-->
</section>  
<style type="text/css">
  #w{
    font-size: 100px;
    font-weight: bold;
    font-family: Forte;
     color:#331a00;

  }
  #r{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
     color:#331a00;


  }
   #i{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color:#331a00;

  }
   #t{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color:#331a00;

  }
   #e{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color:#331a00;

  }
   #w2{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color: #ff6600;
  }
   #i2{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color: #ff6600;
  }
   #n{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color: #ff6600;
  }
   #g{
 font-size: 100px;
    font-weight: bold;
    font-family: Forte;
    color: #ff6600;
  }
  #g2{
    font-size: 60px;
    font-weight: bold;
    font-family: Forte;
    color:  #00cc00;
  }
  #e3{
    font-size:55px;
    color:#331a00;

  }
  #nav_ul li{
    width:120px;
    border-style:outset;
    border:1px solid #f5f5f0;
    height:60px;
    line-height: 40px;

  }
  #nav_ul  li a{
    color:black;
    font-weight: bold;
    font-size:13px;
    text-align: center;
    text-transform:uppercase;

  }
  .active{
    color:red;
  }
  #en{
    width:170px !important;
  }
  #te{
    width: 150px !important;
  }
  #nav_a{
    background:black;
  }
  #nav {
    
  }
  #nav_section{
    border-top:4px solid black;
  }
#card{
  width:113px;
  height:135px;
  background: black;
  border-radius: 0px;
}
#card h3{
  color: white;
  font-weight: bold;
}
#card span{
  color:white;
  font-weight: bold;
}
.active{
  color:red !important;
}
#card_2{
  height:65px;
}
</style>
<section>
<p>
  <span id="w">W</span>
  <span id="r">r</span>
  <span id="i">i</span>
  <span id="t">t</span>
  <span id="e">e</span>
  <sup id="e3"><i class="fas fa-pencil-alt"></i></sup>
  <span id="w2">w</span>
  <span id="i2">i</span>
  <span id="n">n</span>
  <span id="g">g</span>
  <sup id="g2"><i class="fas fa-feather-alt"></i></sup>
  </p>
</section>
<section class="container-fluid" id="nav_section">
<div class="row">
<div class="col-sm-1 col-lg-1 col-md-1">
  <div class="card text-center" id="card">
    <h3 class="mt-1">15</h3>
    <span>August</span>
     <span>Monday</span>
  </div>
</div>
<div class="col-sm-11 col-lg-11 col-md-11 mx-auto">
  <!--Main Navigation-->
<header>

  <nav class="navbar  navbar-expand-lg navbar-dark scrolling-navbar" id="nav">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto" id="nav_ul">
        <li class="nav-item active" id="nav_li" >
          <a class="nav-link active" href="#" >Home&nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item" id="te">
          <a class="nav-link" href="#">Technology&nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">sports &nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">politics &nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Education &nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item" id="en">
          <a class="nav-link" href="#">entertainment &nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Breaking&nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Defence &nbsp;<i class="fa fa-caret-down"></i></a>
        </li><li class="nav-item">
          <a class="nav-link" href="#">Top 10 &nbsp;<i class="fa fa-caret-down"></i></a>
        </li>
      </ul>
     
    </div>

  </nav>
   <div class="row">
  <div class="col-sm-12 col-lg-12 col-md-12" ">
  <div class="card mt-1" style="border-radius: 0px;height:46px;">
  <div class="row">
    <div class="col-lg-2 col-sm-2 col-md-2 mx-auto">
      <a href="#" class="" style="line-height:46px;color:black;border:1px solid #f5f5f0;font-weight: bold;">TRENDING NOW</a>
    </div>
    <div class="col-lg-7 col-sm-7 col-md-7 mx-auto">
     <marquee style="line-height:46px;">
       <img src="include/media/bjp.jpg" alt="thumbnail" class="rounded"
  style="width:40px;height:40px;font-weight: bold;">
  <a style="color:red;font-weight: bold;">this is an example
   <sup><img src="include/media/new.jpg" style="height:30px;width:30px;"></sup>
  </a>
   <img src="include/media/bjp.jpg" alt="thumbnail" class="rounded"
  style="width:40px;height:40px;">
  <a style="color:red;font-weight: bold;">this is an example  <sup><img src="include/media/new.jpg" style="height:30px;width:30px;"></sup></a>
   <img src="include/media/bjp.jpg" alt="thumbnail" class="rounded"
  style="width:40px;height:40px;">
  <a style="color:red;font-weight: bold;">this is an example  <sup><img src="include/media/new.jpg" style="height:30px;width:30px;"></sup></a>
     </marquee>
    </div>
    <div class="col-sm-3 col-lg-3 col-md-3">
    <div class="card mt-1 z-depth-0"> <!-- Default input -->
    <input type="text" id="exampleForm2" class="form-control z-depth-0" style="width:95%;" placeholder="Enter Your Pin code Here">
    <button class="btn z-depth-0" type="submit" style="width:15px;position: absolute;right:0px;bottom:7px;color:#999966;height:25px;">
    <i class="fas fa-search" style="line-height:15px;font-size:14px;"></i></button>
    </div>
  </div>
  </div>
  </div>
   
  </div> 
  
  </div>
</div>
</header>


</div>
</div>

<!--Main Navigation-->
</section>
<section class="">
<div class="row">

  <div class="col-lg-8  float-right mx-auto " style="">
  <div class="float-right mt-5">
  <div class="chip chip-md aqua-gradient darken-2 white-text z-depth-1">
  <img src="nc.jpg" alt="Contact Person"> <a href="include/nc.php" class="white-text" target="blank">National Capital</a>
</div>
<div class="chip chip-md peach-gradient darken-2 white-text z-depth-1">
  <img src="east.jpg" alt="Contact Person"> <a href="include/es.php" class="white-text">Eastern States</a>
</div>
<div class="chip chip-md dusty-grass-gradient danger-2 white-text z-depth-1">
  <img src="west.jpg" alt="Contact Person"><a href="western.php" class="white-text">Western States</a>
</div>

<div class="chip chip-md young-passion-gradient darken-2 white-text z-depth-1">
  <img src="north.jpg" alt="Contact Person"><a href="nothern.php" class="white-text">Northern States</a>
</div>

<div class="chip chip-md near-moon-gradient darken-2 white-text z-depth-1">
  <img src="south.jpg" alt="Contact Person"><a href="southern.php" class="white-text">Southern States</a>
</div>
  </div>
    </div></div>
<!--/.Navbar-->
<!--/.Navbar -->
</section>
<section>
  
</section>

  <!-- Start your project here-->
 <!--Main Navigation-->
  

<style type="text/css">
  #a_title:hover{
    color:red;
  }
  #a_2{
    font-weight: bold;
    text-transform: uppercase;
  }
  #a_2:hover{
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:red;
  }
  #a2:hover{
    color:red !important;
  }
  #editor{
    color:#004d4d;;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:#004d4d;
  }
  #title {
    font-family:Segoe Print !important;
    color:#004d4d;
    font-weight: normal;
    text-transform: uppercase;
    font-size: 15px;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
          
  }
  #title a{
     color:#004d4d;
  }
  #title:hover a{
    color:red;
    text-shadow:0px 0px 0px;
  }
.b_title{
  text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:#004d4d;
}
</style>
<main>
<section>
<h3 class="text-center">
<span class="badge badge-danger">TECHNOLOGY</span></h3>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="card">
        <div class="row">
          <div class="col-lg-6 col-md-10 col-sm-10 mx-auto ml-1">
            
      <div class="card" style="background: url(include/media/bsr.jpg);height:400px;border-radius: 0px;">
        <div class="card-body">
          <h3><span class="badge badge-danger" style="float: bottom;position: absolute;bottom:150px;">Technology</span></h3>
          <h2 style="position: absolute;bottom:50px;font-weight: bold;color:white;">This is just an example of our technology post</h2>
          <span style="position: absolute;bottom: 20px;font-weight: bold;">Shashi shekhar pathak</span>
        </div>
      </div>
    </div>
     <div class="col-lg-6 col-md-10 col-sm-10 mx-auto">
      <div class="card" style="background: url(include/media/nba.jpg);height:400px;border-radius: 0px;background-repeat: no-repeat;background-size: cover;">
        <div class="card-body">
          <h3><span class="badge badge-danger" style="float: bottom;position: absolute;bottom:150px;">Technology</span></h3>
          <h2 style="position: absolute;bottom:50px;font-weight: bold;color:white;">This is just an example of our technology post</h2>
          <span style="position: absolute;bottom: 20px;font-weight: bold;">Shashi shekhar pathak</span>
        </div>
      </div>
      </div>
          </div><!--half grid-->
          <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6 mx-auto my-2">
              <div class="card" style="background: url(include/media/ip.jpg);height:300px;border-radius: 0px;background-repeat: no-repeat;background-size: cover;">
        <div class="card-body">
          <h5><span class="badge badge-danger" style="float: bottom;position: absolute;bottom:150px;">Technology</span></h5>
          <h4 style="position: absolute;bottom:50px;font-weight: bold;color:white;">This is just an example of our technology post</h4>
          <span style="position: absolute;bottom: 20px;font-weight: bold;">Shashi shekhar pathak</span>
        </div>
      </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mx-auto my-2">
              <div class="card" style="background: url(include/media/ip2.jpg);height:300px;border-radius: 0px;background-repeat: no-repeat;background-size: cover;">
        <div class="card-body">
          <h5><span class="badge badge-danger" style="float: bottom;position: absolute;bottom:150px;">Technology</span></h5>
          <h4 style="position: absolute;bottom:50px;font-weight: bold;color:white;">This is just an example of our technology post</h4>
          <span style="position: absolute;bottom: 20px;font-weight: bold;">Shashi shekhar pathak</span>
        </div>
      </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mx-auto my-2">
              <div class="card" style="background: url(include/media/ip3.jpg);height:300px;border-radius: 0px;background-repeat: no-repeat;background-size: cover;">
        <div class="card-body">
          <h5><span class="badge badge-danger" style="float: bottom;position: absolute;bottom:150px;">Technology</span></h5>
          <h4 style="position: absolute;bottom:50px;font-weight: bold;color:white;">This is just an example of our technology post</h4>
          <span style="position: absolute;bottom: 20px;font-weight: bold;">Shashi shekhar pathak</span>
        </div>
      </div>
            </div>

          </div>
        </div>
      </div><!--first grid-->
      </div>
    </div>
  </div>
</section>
<section id="top_10">
 <h1 class=" text-center my-1" style="font-weight: bold;
               color:#ff3300;
               font-size:40px;
              
               ">
         <span class="badge badge-danger">TOP 10 </span>
         </h1>
  <div class="container" style="background: #fff7e6;">


    <div class="row">
    
    <?php
  $con=mysqli_connect("localhost","root","","writewing");
  $sel="SELECT * FROM english_top_10";
  $select=mysqli_query($con,$sel);
  while($data=mysqli_fetch_array($select)){
$img_1=$data["p_img1"];
$p_desc=$data["p_desc1"];
$id=$data["id"];
$title=$data["title"];
   ?>
      

      <div class="col-lg-4 col-md-6 col-sm-10 mt-5 mb-5">
      
       
     <div class="card promoting-card"  style="max-height: 400px;">

  <!-- Card content -->
  <div class="card-body d-flex flex-row">

    <!-- Avatar -->
    <img src="include/top10/<?php echo $img_1; ?>" class="rounded-circle mr-3" height="50px" width="50px" alt="avatar">

    <!-- Content -->
    <div>

      <!-- Title -->
      <h5 class="card-title font-weight-bold mb-2" id="title" style="
text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:#004d4d;
             text-transform: uppercase;

      "><a><?php echo $title; ?></a></h5>
      <!-- Subtitle -->
      <p class="card-text"><i class="far fa-clock pr-2"></i>07/24/2018</p>

    </div>

  </div>

  <!-- Card image -->
  <div class="view overlay">
    <img class="card-img-top rounded-0" src="include/top10/<?php echo $img_1; ?>" alt="Card image cap" style="height:200px;">
    <a href="#!">
      <div class="mask rgba-white-slight"></div>
    </a>
  </div>

  <!-- Card content -->
  <div class="card-body">

    <div class="">

      <!-- Text -->
      <p class="card-text">
      <?php if(strlen($p_desc)>25) { echo (substr($p_desc, 0,70))."........"; ?></p>
      <!-- Button -->
      <a class="btn btn-danger btn-lg p-1 my-1 mr-0 " href="include/top_10_full.php?id=<?php echo $id; ?>">
        Read More&nbsp;<i class="fas fa-arrow-right"></i>
      </a>
      <?php } ?>
      <i class="fas fa-share-alt text-muted float-right p-1 my-1" data-toggle="tooltip" data-placement="top" title="Share this post"></i>
      <i class="fas fa-heart text-muted float-right p-1 my-1 mr-3" data-toggle="tooltip" data-placement="top" title="I like it"></i>

    </div>

  </div>

</div>
  
    </div>
 <?php } ?> 
  </div>
 
      
  <!-- Grid row -->
</div>
</section>
<!-- Section: Blog v.2 -->
      </div>
     
    </div><!--- -->
    
  </div><!--container -->
</section>

<section class="mt-5" style="background:;">
  <h3 class="text-center text-danger font-weight-bold">
   <span class="badge badge-danger">DEFENCE</span>
   </h3>
  <div class="container">
    <div class="row">
    <?php
  $con=mysqli_connect("localhost","root","","writewing");
  $sel="SELECT * FROM english_3_img where p_category='DEFENCE' order by id desc limit 0,2";
  $select=mysqli_query($con,$sel);
  while($three=mysqli_fetch_array($select)){
$img_1=$three["p_img1"];
$p_desc=$three["p_desc1"];
$id=$three["id"];
$p_category=$three["p_category"];
$title=$three["p_title"];
$date=$three["p_date"];
$id=$three["id"];
   ?>
      
      <div class="col-sm-10 col-lg-6 col-md-6 mx-auto">
        <div class="view overlay rounded z-depth-0">
      <img src="include/img_3/<?php echo $img_1; ?>" class="img-fluid" alt="Sample project image" style="height: 400px;">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="">
        <h3><span class="font-weight-bold mt-2 mb-3 badge badge-warning"><i class="fas fa-shield-alt"></i>&nbsp;&nbsp;Defence</span></h3>
        
      </a>
     <h4 class=" mb-3"  style="font-size:20px;
             color:#004d4d;" id=""><?php echo $title; ?></h4>
      <p> <?php if(strlen($p_desc)>25) { echo (substr($p_desc, 0,100))."........"; }?></p>
      <a class="btn btn-danger btn-rounded" href="include/img_3_post.php?id=<?php echo $id; ?>" target="blank"> View &nbsp;<i class="far fa-hand-point-right"></i></a>
    </div>
      </div><!--first grid-->
      <?php } ?>
         <?php 
       $sel="SELECT * FROM english_1_img where category='DEFENCE' order by id desc limit 0,3 ";
       $select=mysqli_query($con,$sel);
       while($data=mysqli_fetch_array($select)){
        $title=$data["title"];
        $desc=$data["p_desc"];
        $category=$data["category"];
        $img=$data["p_img"];
        $desc2=$data["p_desc_2"];
        $desc3=$data["p_desc_3"];
        $id=$data["id"];
          ?>
          <div class="col-sm-10 col-lg-4 col-md-6 mx-auto mt-2">
        <div class="view overlay rounded z-depth-0">
      <img src="include/img_1/<?php echo $img; ?>" class="img-fluid" alt="Sample project image" style="height:250px;">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="">
        <h4><span class="font-weight-bold mt-2 mb-3 badge badge-warning"><i class="fas fa-shield-alt"></i>&nbsp;&nbsp;Defence</span></h4>
      </a>
     <h4 class=" mb-3"  style="color:grey;
             color:#004d4d;font-size: 20px;"><?php echo $title; ?></h4>
      <p><?php if(strlen($desc)>25) { echo (substr($desc, 0,120))."........"; }?></p>
      <a class="btn btn-danger  btn-sm" href="include/img_1_post.php?id=<?php echo $id; ?>"> View &nbsp;
      <i class="far fa-hand-point-right"></i></a>
    </div>
    
      </div>
<?php } ?>
      <!--third grid-->
       <?php 
       $selt="SELECT * FROM english_3_img where p_category='DEFENCE' order by id desc limit 0,4";
       $selet=mysqli_query($con,$selt);
       while($data=mysqli_fetch_array($selet)){
        $title=$data["p_title"];
        $desc=$data["p_desc1"];
        $category=$data["p_category"];
        $img=$data["p_img1"];
        $desc2=$data["p_desc2"];
        $desc3=$data["p_desc3"];
        $id=$data["id"];
          ?>
        <div class="col-sm-10 col-lg-3 col-md-6 mx-auto mt-2">
        <div class="view overlay rounded z-depth-0">
      <img src="include/img_3/<?php echo $img; ?>" class="img-fluid" alt="Sample project image" style="height: 200px;">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="">
       <h5><span class="font-weight-bold mt-2 mb-3 badge badge-warning"><i class="fas fa-shield-alt"></i>&nbsp;&nbsp;Defence</span></h5>
      </a>
     <h4 class="mb-3"  style="color:grey;
             color:#004d4d;font-size: 20px;" ><?php echo $title; ?></h4>
    <p><?php if(strlen($desc)>25) { echo (substr($desc, 0,120))."........"; }?></p>
      <a class="btn btn-danger btn-rounded btn-sm" href="include/img_3_post.php?id=<?php echo $id; ?>"> View 
      &nbsp;<i class="far fa-hand-point-right"></i></a>
    </div>
      </div>
      <!--third grid-->
        <?php } ?>
        
       
    </div>
  </div>
</section>
<section>
  <div class="container my-5">
    <div class="row">
    <div class="col-lg-1"></div>
      <div class="col-sm-10 col-md-10 col-lg-10">
        <form>
          <input type="search" name="search" class="form-control z-depth-0" placeholder="Enter Your Keywords/Words" style="height:55px;font-size:25px;border-right:none;">
        <button class="btn btn-outline-red float-right z-depth-0" style="margin-top: -55px;height: 55px;margin-right:-5px;width: 150px;">  <i class="fas fa-search" style="font-size: 25px;"></i></button>
        </form>
      </div>
    </div>
  </div>
</section>
<section>

<h3 class="text-center text-danger font-weight-bold" style="text-transform: uppercase;">
<span class="badge badge-danger"> Sports</span>
<hr class="purple-gradient" style="height: 2px;width: 200px;">
</h3>

  <div class="container">
    <div class="row" style="">

    <h3 class="text-center text-success pl-1 mb-4 font-weight-bold mt-5" style="text-transform:uppercase;
    border-left: 10px solid #ff0066;">Cricket</h3>
      <div class="col-lg-11 col-md-11 col-sm-10 mx-auto " style="background: #e6e6ff;">
<!-- Section: Magazine v.2 -->
<section class="magazine-section my-5">
  <!-- Section heading -->
  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <?php 
 $con=mysqli_connect("localhost","root","","writewing");
 $sel="SELECT * FROM english_1_img where category='CRIRCKET' order by id desc limit 0,1";
 $select=mysqli_query($con,$sel);
 $get=mysqli_fetch_array($select);
 $img1=$get["p_img"];
 $p_category=$get["category"];
 $title=$get["title"];
 $p_desc1=$get["p_desc"];
 $id=$get["id"];

     ?>
    <div class="col-lg-6 col-md-12">

      <!-- Featured news -->
      <div class="single-news mb-lg-0 mb-4">

        <!-- Image -->
        <div class="view overlay rounded z-depth-1-half mb-4">
          <img class="img-fluid" src="include/img_1/<?php echo $img1; ?>" alt="Sample image" style="width: 100%;height:300px;">
          <a>
            <div class="mask rgba-white-slight"></div>
          </a>
        </div>

        <!-- Data -->
        <div class="news-data d-flex justify-content-between">
          <a href="#!" class="deep-orange-text">
            <h3 class="font-weight-bold">
            <span  class="badge badge-danger"><i class="fas fa-baseball-ball"></i>&nbsp;&nbsp;<?php echo $p_category; ?></span></h3>
          </a>
          <p class="font-weight-bold dark-grey-text"><i class="fas fa-clock-o pr-2"></i>27/02/2018</p>
        </div>

        <!-- Excerpt -->
        <h3 class="  mb-3 " id="" style="color:#004d4d;font-size: 20px;"><a><?php echo $title; ?></a></h3>
        <p class="dark-grey-text mb-lg-0 mb-md-5 mb-4">
        <p><?php if(strlen($p_desc1)>25) { echo (substr($p_desc1, 0,150))."........"; }?></p></p>
      </div>
      <!-- Featured news -->
      <a href="include/img_1_post.php?id=<?php echo $id; ?>" class="btn btn-danger btn-rounded">
      <i class="far fa-hand-point-right"></i>&nbsp;View
       </a>
    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-6 col-md-12">
      <!-- Small news -->
      <?php 
   $get="SELECT *FROM english_3_img where p_category='CRIRCKET' order by id desc limit 0,6";
   $fetch=mysqli_query($con,$get);
   while($data=mysqli_fetch_array($fetch)){
$titled=$data["p_title"];
$p_desc=$data["p_desc1"];
$img=$data["p_img1"];
$id=$data["id"];

      ?>
        <div class="row">
          <!-- Grid column -->
          <div class="col-md-3">
            <!--Image-->
            <div class="view overlay rounded z-depth-1 mb-4">
              <img class="img-fluid" src="include/img_3/<?php echo $img; ?>" alt="Sample image">
              <a>
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
          </div>
          <!-- Grid column -->
          <!-- Grid column -->
          <div class="col-md-9">
            <!-- Excerpt -->
            <p class="font-weight-bold dark-grey-text">26/02/2018</p>
             <a href="#!" class="deep-orange-text">
            <h5 class="font-weight-bold">
            <span  class="badge badge-danger"><i class="fas fa-baseball-ball"></i>&nbsp;&nbsp;<?php echo $p_category; ?></span></h5>
          </a>
            <div class="d-flex justify-content-between">
              <div class="col-11 text-truncate pl-0 mb-3">
                <a href="#!" class="" style="color:#004d4d;">
               <?php echo $titled; ?></a>
              </div>
              <a href="include/img_3_post.php?id=<?php echo $id; ?>" class="">
              <h3><i class="fas fa-angle-double-right"></i></h3></a>
            </div>
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
<?php } ?>
      </div>
     
      <!-- Small news -->
     
    </div>
    <!--Grid column-->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Magazine v.2 -->
  </div>
      <!--grid -->
     
    </div>
    <div class="row mt-5" style="">
     <h3 class="text-center text-success pl-1 mb-4 font-weight-bold mt-5" style="text-transform:uppercase;
    border-left: 10px solid #ff0066;">
    <span class="badge badge-danger">Football</span>
    </h3>
      <div class="col-lg-11 col-md-11 col-sm-10 mx-auto">
        <!-- Section: Magazine v.2 -->
<section class="magazine-section my-5">
  <!-- Section heading -->
  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
   <?php 
 $con=mysqli_connect("localhost","root","","writewing");
 $sel="SELECT * FROM english_1_img where category='FOOTBALL' order by id desc limit 0,1";
 $select=mysqli_query($con,$sel);
 $get=mysqli_fetch_array($select);
 $img1=$get["p_img"];
 $p_category=$get["category"];
 $title=$get["title"];
 $p_desc1=$get["p_desc"];
 $id=$get["id"];

     ?>
    <div class="col-lg-6 col-md-12">
    

      <!-- Featured news -->
      <div class="single-news mb-lg-0 mb-4">

        <!-- Image -->
        <div class="view overlay rounded z-depth-1-half mb-4">
          <img class="img-fluid" src="include/img_1/<?php echo $img1; ?>" alt="Sample image">
          <a>
            <div class="mask rgba-white-slight"></div>
          </a>
        </div>

        <!-- Data -->
        <div class="news-data d-flex justify-content-between">
          <a href="#!" class="deep-orange-text">
            <h3 class="font-weight-bold"><i class="fas fa-futbol"></i>&nbsp;&nbsp;<span class="badge badge-danger"><?php echo $p_category; ?></span></h3>
          </a>
          <p class="font-weight-bold dark-grey-text"><i class="fas fa-clock-o pr-2"></i>27/02/2018</p>
        </div>

        <!-- Excerpt -->
        <h3 class="font-weight-bold  mb-3 " id="" style="font-size:20px;color:#004d4d;"><a><?php echo $title; ?></a></h3>
        <p><?php if(strlen($p_desc1)>25) { echo (substr($p_desc1, 0,250))."........"; }?></p>
         <a href="include/img_1_post.php?id=<?php echo $id; ?>" class="btn btn-info btn-rounded btn-lg float-right"><i class="far fa-hand-point-right"></i>&nbsp;View</a>
      </div>
      <!-- Featured news -->

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-6 col-md-12">

      <!-- Small news -->
      <div class="single-news mb-4">
 <?php 
   $get="SELECT *FROM english_3_img where p_category='FOOTBALL' order by id desc limit 0,4";
   $fetch=mysqli_query($con,$get);
   while($data=mysqli_fetch_array($fetch)){
$titl=$data["p_title"];
$p_desc=$data["p_desc1"];
$category=$data["p_category"];
$img=$data["p_img1"];
$id=$data["id"];

      ?>
        <!-- Grid row -->
        <div class="row">

          <!-- Grid column -->
          <div class="col-md-3">

            <!--Image-->
            <div class="view overlay rounded z-depth-1 mb-4">
              <img class="img-fluid" src="include/img_3/<?php echo $img; ?>" alt="Sample image">
              <a>
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>

          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-9">

            <!-- Excerpt -->
            <p class="font-weight-bold dark-grey-text">26/02/2018</p>
            <h5><i class="fas fa-futbol orange-text"></i>&nbsp;&nbsp;<span class="badge badge-danger"><?php  echo $category; ?></span></h5>
            <div class="d-flex justify-content-between">
              <div class="col-11  pl-0 mb-3">
                <a href="#!" class="" style="color:#004d4d;font-size: 20px;">
                <?php echo $titl; ?></a>
              </div>
              <a href="include/img_3_post.php?id=<?php echo $id; ?>" style="font-size: 20px;"><i class="fas fa-angle-double-right"></i></a>
            </div>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </div>
      <!-- Small news -->
<?php } ?>
    </div>
    <!--Grid column-->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Magazine v.2 -->
      </div><!---grid -->
    </div><!--row -->
    </div>
    <div class="container-fluid">
    <div class="row" style="">
    <h3 class="text-success text-center font-weight-bold pl-2  ml-4" style="text-transform:uppercase;border-left: 10px solid #ff0066;">Others</h3>
      <div class="col-lg-11 col-md-11 col-sm-10 mx-auto mt-5" style="background:#f9ffe6;">
      <div class="row">
       <?php 
 $con=mysqli_connect("localhost","root","","writewing");
 $sel="SELECT * FROM english_1_img where category='OTHERS' order by id desc limit 0,2";
 $select=mysqli_query($con,$sel);
 while($get=mysqli_fetch_array($select)){
 $img1=$get["p_img"];
 $p_category=$get["category"];
 $title=$get["title"];
 $p_desc1=$get["p_desc"];
 $id=$get["id"];

     ?>
      <div class="col-lg-6 col-md-6 col-sm-10
       mb-4">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-0">
      <img src="include/img_1/<?php echo $img1; ?>" class="z-depth-0 img-fluid" alt="Sample project image">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="green-text">
        <h3 class=""><i class="fas fa-running orange-text"></i>&nbsp;&nbsp;<span class="badge badge-danger">Sports</span></h3>
      </a>
      <p class="font-weight-bold" style="font-size: 20px;color:#004d4d;" 
      ><?php echo $title; ?></p>
      <a class="btn btn-success btn-rounded" href="include/img_1_post.php?id=<?php echo $id; ?>">
       View more &nbsp;&nbsp; <i class="far fa-hand-point-right"></i></a>
    </div>
  </div>
  <?php } ?>
  </div>
  <div class="row">
   <?php 
   $get="SELECT *FROM english_3_img where p_category='OTHERS' order by id desc limit 0,3";
   $fetch=mysqli_query($con,$get);
   while($data=mysqli_fetch_array($fetch)){
$titl=$data["p_title"];
$p_desc=$data["p_desc1"];
$category=$data["p_category"];
$img=$data["p_img1"];
$id=$data["id"];

      ?>
    <div class="col-lg-4 col-sm-10 col-md-6 mx-auto">
      <div class="view overlay rounded z-depth-2">
      <img src="include/img_3/<?php echo $img; ?>" class="img-fluid" alt="Sample project image" style="height:250px;width: 100%;">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="green-text">
        <h3 class="font-weight-bold mt-2 mb-3"><span class="badge badge-danger"><i class="fas fa-running"></i>&nbsp;&nbsp;Sports</span></h3>
      </a>
      <p class="font-weight-bold"
      style="font-size: 20px;color:#004d4d;"><?php echo $titl; ?></p>
      <a class="btn btn-warning btn-rounded btn-md" href="include/img_3_post.php?id=<?php echo $id; ?>">
       View more&nbsp;&nbsp;<i class="far fa-hand-point-right"></i></a>
    </div>
    </div>
    <?php } ?>
  </div>
  <!-- Grid column -->
      </div><!--grid -->
      <div class="col-lg-4 col-md-6 col-sm-10 mx-auto">
        <div class="row">
          
        </div>
      </div>
    </div><!--row-->
    
    </div>
    <!-- Grid row -->
</section>
<section>

<h2 class="text-center text-danger font-weight-bold" style="">
<span class="badge badge-danger">POLITICS</span>

</h2>
  <div class="container" style="background: #ebebe0;">
    <div class="row">
    <?php
     $con=mysqli_connect("localhost","root","","writewing");
     $sel="SELECT * FROM english_3_img where p_category='POLITICS' order by rand() limit 0,1";
     $select=mysqli_query($con,$sel);
     $detail=mysqli_fetch_array($select);
     $title=$detail["p_title"];
     $category=$detail["p_category"];
     $img_1=$detail["p_img3"];
     $id=$detail["id"];
     $desc=$detail["p_desc1"];

     ?>

      <div class="col-sm-10 col-lg-12 col-md-10 mx-auto mt-5">
      <div class="row">
        <div class="col-sm-10 col-lg-7 col-md-7" id="first_animate">
          <div class="card z-depth-0">
            <div class="card-header" style="background: white;">
              <h5 class="text-left font-weight-bold"
               style="text-transform: uppercase;color:grey;
             color:#004d4d;

              " >
              <a id="a_title"><?php echo $title; ?></h5></a>
            </div>
            <div class="card-body">
              <img src="include/img_3/<?php echo $img_1; ?>" class="img-fluid z-depth-0 img-thumbnail" alt="1">
              <h3><span class="badge badge-danger"><?php echo $category; ?></span></h3>
             <a><p class="text-info">Shashi shekhar pathak</p></a>
             <p class="text-left ">
               
               <?php
                 if(strlen($desc)>70){
                  echo (substr($desc, 0,120))."........";
                 }

                ?>
             </p>
             <a href="#" class="btn btn-danger btn-md btn-rounded float-right">READ MORE
             &nbsp;&nbsp;
              <i class="far fa-hand-point-right"></i>
             </a>
            </div>
          </div>
        </div> <!--child colm-->     
        <div class="col-sm-10 col-lg-5 col-md-5" id="animate_second">
          <div class="card z-depth-0">
           <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img where p_category='POLITICS' order by rand() limit 0,5";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];
      ?>
<div class="row mt-2">
    <!-- Grid column -->
 <div class="col-lg-5">
      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0 mb-lg-0 mb-4 ml-2">
        <img class="img-fluid" src="include/img_3/<?php echo $image; ?>" alt="Sample image" 
        style="height:100px;width:200px;">
        <h4 class="badge badge-danger"><?php echo $category; ?></h4>
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>
    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
      <a href="#" class="mt-2" id="" style="font-weight: bold;
      color:#004d4d;
           
             "><p><?php echo $title;  ?></p>
             <a href="#" class="btn btn-success z-depth-0 float-right btn-sm ">More&nbsp;
              &nbsp;&nbsp;
              <i class="far fa-hand-point-right"></i></a>
             </a>
      <!-- Post data -->
    </div>
    <!-- Grid column -->
  </div>
  <?php } ?>
  </div>
  
  
  
  <!--card-->
        </div> <!--colsm-5--> 
      </div><!--child row-->
    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="mb-5 mt-4">

</section>
<!-- Section: Blog v.4 -->
      </div><!--grid-->
    </div><!--row -->
  </div><!--container -->
</section>
<section class="mt-5">

<h3 class="text-center text-danger font-weight-bold" style="">
<span class="badge badge-danger">BREAKING NEWS</span>

</h3>
  <div class="container" style="background:#fff2e6;">
    <div class="row">
     <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img where p_category='CRIRCKET' order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $titlen=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];
              $id=$data["id"];
      ?>
      <div class="col-lg-5 col-md-6 col-sm-10 mx-auto">
        <!-- Section: Blog v.1 -->
<section class="my-5">
  <!-- Section heading -->
  <!-- Grid row -->
  <div class="row">
    <!-- Grid column -->
    <div class="col-lg-6">
      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-lg-0 mb-4">
        <img class="img-fluid" src="include/img_3/<?php echo $image; ?>" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-6">

      <!-- Category -->
      <a href="#!" class="green-text">
        <h4 class="font-weight-bold mb-3"><span class="badge badge-danger">BREAKING</span></h4>
      </a>
      <!-- Post title -->
      <h5 class="font-weight-bold mb-3"><strong><?php echo $titlen; ?></strong></h5>
      <!-- Excerpt -->
     <p><?php if(strlen($desc)>25) { echo (substr($desc, 0,250))."........"; }?></p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 19/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-success btn-rounded btn-md" href="include/img_3_post.php?id=<?php echo $id; ?>">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <?php
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img where p_category='OTHERS' order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $titlen=$data["p_title"];
              $category=$data["p_category"];
              $desc1=$data["p_desc1"];
              $image=$data["p_img1"];
              $id=$data["id"];
      ?>
    <div class="col-lg-6">

      <!-- Category -->
      <a href="#!" class="pink-text">
        <h5 class="font-weight-bold mb-3">
        <span class="badge badge-danger">BREAKING</span></h5>
      </a>
      <!-- Post title -->
      <h5 class="font-weight-bold mb-3"><strong><?php echo $titlen; ?></strong></h5>
      <!-- Excerpt -->
      <p><?php if(strlen($desc1)>25) { echo (substr($desc1, 0,200))."........"; }?></p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 14/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-pink btn-rounded btn-md mb-lg-0 mb-4" href="include/img_3_post.php?id=<?php echo $id; ?>">Read more</a>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    
    <div class="col-lg-6">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2">
        <img class="img-fluid" src="include/img_3/<?php echo $image; ?>" alt="Sample image">
        <a>
        </a>
      </div>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <?php
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img where p_category='FOOTBALL' order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $titlen=$data["p_title"];
              $category=$data["p_category"];
              $desc1=$data["p_desc1"];
              $image=$data["p_img1"];
              $id=$data["id"];
      ?>
    <div class="col-lg-6">

      <!-- Category -->
      <a href="#!" class="pink-text">
        <h5 class="font-weight-bold mb-3">
        <span class="badge badge-danger">BREAKING</span></h5>
      </a>
      <!-- Post title -->
      <h5 class="font-weight-bold mb-3"><strong><?php echo $titlen; ?></strong></h5>
      <!-- Excerpt -->
      <p><?php if(strlen($desc1)>25) { echo (substr($desc1, 0,200))."........"; }?></p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 14/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-pink btn-rounded btn-md mb-lg-0 mb-4" href="include/img_3_post.php?id=<?php echo $id; ?>">Read more</a>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    
    <div class="col-lg-6">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2">
        <img class="img-fluid" src="include/img_3/<?php echo $image; ?>" alt="Sample image">
        <a>
        </a>
      </div>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Blog v.1 -->
      </div><!--first grid-->
      <div class="col-lg-7 col-md-6 col-sm-10 mx-auto mt-5">
        <div class="row">
<?php
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img where p_category='DEFENCE' order by rand() limit 0,6";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $titlen=$data["p_title"];
              $category=$data["p_category"];
              $desc1=$data["p_desc1"];
              $image=$data["p_img1"];
              $id=$data["id"];
      ?>
          <div class="col-lg-6 col-md-6 col-sm-10 mx-auto">
           
    <div class="view overlay rounded z-depth-2">
      <img src="include/img_3/<?php  echo $image; ?>" class="img-fluid" alt="Sample project image" style="height: 200px;width: 100%;">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="green-text">
        <h3 class="font-weight-bold mt-2 mb-3"><span class="badge badge-danger">BREAKING</span></h3>
      </a>
      <h4 class="font-weight-bold mb-3"><?php echo $titlen ?></h4>
       <p><?php if(strlen($desc1)>25) { echo (substr($desc1, 0,200))."........"; }?></p>
      <a class="btn btn-success btn-rounded btn-md" href="include/img_3_post.php?id=<?php echo $id; ?>"> View more</a>
    </div>
  </div>
  <?php } ?>
  <!-- Grid column -->
<!--small grid-->
           
     
   
        </div>
      </div>
    </div>
  </div>
</section>

<h3 class="text-center text-danger font-weight-bold" style="">
<span  class="badge badge-danger">SPOTLIGHT</span>

</h3>
  <div class="container-fluid">
 
    <div class="row">
      <?php $con=mysqli_connect("localhost","root","","writewing");
            $select="SELECT * FROM english_1_img order by rand()  limit 0,1";
            $selected=mysqli_query($con,$select);
            $data=mysqli_fetch_array($selected);
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];


       ?>

      <div class="col-sm-10 col-lg-3 col-md-3" style="" id="third_animate">
        <!-- Card -->
<div class="card card-image mb-3" style="
background-image: url('include/img_1/<?php echo $img; ?>');">
    <div class="text-white text-center d-flex align-items-center img-gradient-overlay py-5 px-4">
        <div>
            <h5 class="badge badge-danger"><i class="fas fa-desktop"></i>&nbsp;<?php echo $category; ?></h5>
            <h5 class="card-title pt-2" style="background: white;color:black;"><strong>
            <a href="#"><?php echo $title; ?></a></strong></h5>

            <a class="btn btn-outline-white waves-effect waves-light"
                href="include/single_post.php?id=<?php echo $id; ?>" 

            ><i class="far fa-clone left"></i> View</a>
        </div>
    </div>
</div>
<!-- Card -->
      </div><!-- col-3-->
      <div class="col-sm-10 col-lg-6 col-md-6" id="fourth_animate">
       <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];
              $id=$data["id"];
      ?>
        <div class="card card-image mb-3" 
        style="background-image: url('include/img_3/<?php echo $image; ?>');">
    <div class="text-white text-center d-flex align-items-center img-gradient-overlay py-5 px-4">
        <div>
            <h5 class="orange-text"><i class="fas fa-desktop"></i>&nbsp;<?php echo $category; ?></h5>
            <h5 class="card-title pt-2"><strong><?php echo $title; ?></strong></h5>
             <?php if(strlen($desc)>25) { echo (substr($desc, 0,140))."........"; } ?></p>
            <a class="btn btn-outline-white waves-effect waves-light" href="img_3_post.php?id=<?php echo $id; ?>"><i class="far fa-clone left"></i> View</a>
        </div>
    </div>
</div>
<!-- Card -->
      </div><!--col-6-->
        <div class="col-sm-10 col-lg-3 col-md-3 mx-auto" id="fifth_animate">
        <!-- Card -->
         <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
      ?>
        <div>
<div class="card card-image mb-3" style="background-image: url('include/img_1/<?php echo $img; ?>');">
    <div class="text-white text-center d-flex align-items-center img-gradient-overlay py-5 px-4">
        <div>
            <h5 class="orange-text"><i class="fas fa-desktop"></i>&nbsp;<?php echo $skill; ?></h5>
            <h5 class="card-title pt-2"><strong>
            <?php if(strlen($title)>55) { echo (substr($desc, 0,45))."........"; } ?></strong></h5>
             <?php if(strlen($desc)>25) { echo (substr($desc, 0,140))."........"; } ?></p>
            <a class="btn btn-outline-white waves-effect waves-light" href="single_post.php?id=<?php echo $id; ?>"><i class="far fa-clone left"></i> View</a>
        </div>
    </div>
</div>

</div>
<!-- Card -->
      </div>
      <!-- col-3-->
    </div><!--row Layout-->
  </div><!--container Layout-->
</main>  <!--Main Layout-->
<hr class="py-4">
<section>
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12 col-lg-12 col-md-12">
        <div class="row">
          <div class="col-sm-10 col-lg-6 col-md-6 " id="sixth_animate">
            <div class="card z-depth-0">
              <div class="card-header" style="background: white;">
                <h2 class="font-weight-bold"
                ><span class="badge badge-danger">EDITOR'S PICK</span>
                <div class="mt-1 dusty-grass-gradient color-block" style="height:4px;width:300px;background-color:red;"></div>
                </h2>
              </div>
              <div class="card-body">
                <div class="row">
                 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"]; 
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">
      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-lg-0 mb-4">
        <img class="img-fluid" src="include/img_3/<?php echo $image; ?>" alt="Sample image" 
        style="height:200px;width: 100%;">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>
    </div>
    <div class="col-lg-7">
      <!-- Category -->
      <a href="#!" class="indigo-text">
        <h6 class="font-weight-bold mb-3 badge badge-success"><?php echo $category; ?></h6>
      </a>
      <!-- Post title -->
      <h5 class="font-weight-bold" style="  
      text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
              color:#004d4d;" id="title"><strong><a><?php echo $title; ?></a></strong></h5>
      <!-- Excerpt -->
      <?php if(strlen($desc)>25) { echo (substr($desc, 0,100))."........"; } ?></p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 11/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-danger btn-rounded btn-sm">Read more</a>

    </div>
    <hr>
    <!-- Grid column -->
      <?php } ?>
  </div>
 
              </div>

            </div>
          </div><!--child col-->
          <div class="col-lg-6 col-sm-10 col-md-5" id="seventh_animate">
             <div class="card z-depth-0" >
               <div class="card-header text-danger" style="background: white;">
                 <h2 style=""
                 ><span class="badge badge-danger">LATEST</span>

               <div class="mt-1 dusty-grass-gradient color-block" style="height:4px;width:300px;background-color:red;"></div></h2>
               </div>
               <div class="card-body">
    <div class="row">
 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,6";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
      ?>
    <div class="col-lg-6 col-md-6 col-sm-10" >
               <div class="card z-depth-0">
<div class="card booking-card mb-3" style="height: 300px;">
  <!-- Card image -->
  <div class="view overlay">
    <img class="card-img-top" src="
   include/img_1/<?php echo $img; ?>" alt="Card image cap" style="height: 200px;">
    <a href="#!">
      <div class="mask rgba-white-slight"></div>
    </a>
  </div>
  <!-- Card content -->
  <div class="card-body">

    <!-- Title -->
    <h6 class="card-title font-weight-bold"
    style="text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:#004d4d;
             " 

     id="title"><a><?php echo $title; ?></a></h6>
    <!-- Data -->
    <!-- Text -->
    <p class="card-text">
     <?php if(strlen($desc)>25) { echo (substr($desc, 0,100))."........"; } ?>
       
        <a href="#" class="btn btn-sm btn-warning btn-rounded float-right"><i class="fas fa-arrow-right"></i></a>
     </p>
       
    </div>
    </div>
  </div>

</div>
<?php } ?>

<!-- xhildd -->

</div>

<!-- Card -->
               </div>
             </div>
          </div>
        </div><!--child row-->
      </div><!--large grid-->
    </div>
  </div>
</section>
 <h2 class="text-center">
      <span class="badge badge-danger">Our Gallery</span> 
</h2>
<section class="mt-5" style="background:#1f2e2e;">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-10 col-lg-10 col-md-10 mx-auto">
        <div class="row">
  <div class="col-md-12" id="eighth_animate">

    <div id="mdb-lightbox-ui"></div>

    <div class="mdb-lightbox">

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(145).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(145).jpg" class="img-fluid">
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(150).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(150).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(152).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(152).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(42).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(42).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(151).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(151).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(40).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(40).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(148).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(148).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(147).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(147).jpg" class="img-fluid" />
        </a>
      </figure>

      <figure class="col-md-4">
        <a href="https://mdbootstrap.com/img/Photos/Lightbox/Original/img%20(149).jpg" data-size="1600x1067">
          <img alt="picture" src="https://mdbootstrap.com/img/Photos/Lightbox/Thumbnail/img%20(149).jpg" class="img-fluid" />
        </a>
      </figure>

    </div>

  </div>
</div>
      </div>
    </div><!---row -->
  </div><!--container-->
</section>
<hr class="py-1">
<section  style="background:#800033;">
 <div class="container-fluid">
   <div class="row">
     <div class="col-sm-10 col-lg-10 col-md-10 mx-auto" id="ninth_animate">
       <!--Projects section v.4-->
<section>

    <!--Section heading-->
    <h2 class="h1-responsive font-weight-bold white-text my-5 " id=""
              
                style="font-family:Castellar;" >EDITOR'S PICK &nbsp;
    <i class="fas fa-pencil-alt text-success" style="
   color:#004d4d !important;
    text-shadow: 0 1px 0 #ccc, 
               0 2px 0 #c9c9c9,
               0 3px 0 #bbb,
               0 4px 0 #b9b9b9,
               0 5px 0 #aaa,
               0 6px 1px rgba(0,0,0,.1),
               0 0 5px rgba(0,0,0,.1),
               0 1px 3px rgba(0,0,0,.3),
               0 3px 5px rgba(0,0,0,.2),
               0 5px 10px rgba(0,0,0,.25),
               0 10px 10px rgba(0,0,0,.2),
               0 20px 20px rgba(0,0,0,.15) !important"></i>
                <div class="mt-1 dusty-grass-gradient text-center color-block" style="height:4px;width:300px;background-color:red;"></div>
               </h2>
    <!-- Section description -->

    <!--Grid row-->
    <div class="row mx-1">
  <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"]; 
      ?>
        <!--Grid column-->
        <div class="col-md-12 col-lg-12 col-sm-12 mb-4" id="tenth_animate">

            <div class="card card-image" style="background-image: 
            url(include/img_3/<?php echo $image; ?>);">
                <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                    <div>
                        <h6 class="purple-text badge badge-success"><strong><?php echo $category; ?></strong></h6>
                        <h3 class="card-title py-3 font-weight-bold"><strong><?php echo $title; ?></strong></h3>                       <a class="btn btn-secondary btn-rounded"><i class="far fa-clone left"></i>Take a Look</a>
                    </div>
                </div>
            </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
         <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"]; 
      ?>
        <div class="col-md-6 mb-4" id="eleventh_animate">
            <div class="card card-image" style="background-image: 
            url(include/img_3/<?php echo $image; ?>);">
                <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                    <div>
                        <h6 class="pink-text badge badge-danger" ><strong><?php echo $category; ?></strong></h6>
                        <h3 class="card-title py-3 font-weight-bold"><strong><?php echo $title; ?></strong></h3>
                       
                        <a class="btn btn-pink btn-rounded"><i class="far fa-clone left"></i> View Inside</a>
                    </div>
                </div>
            </div>
        </div>
        <!--Grid column-->

        <!--Grid column-->
         <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
        <div class="col-md-6 mb-4">
            <div class="card card-image" style="background-image: 
            url(include/img_1/<?php echo $img; ?>);">
                <div class="text-white text-center d-flex align-items-center rgba-black-strong py-5 px-4">
                    <div>
                        <h6 class="green-text badge badge-warning"><strong><?php echo $category; ?></strong></h6>
                        <h3 class="card-title py-3 font-weight-bold"><strong><?php echo $title; ?></strong></h3>
                       
                        <a class="btn btn-success btn-rounded"><i class="far fa-clone left"></i> View Inside</a>
                    </div>
                </div>
            </div>
        </div>
        <!--Grid column-->

    </div>
    <!--Grid row-->

</section>
<!--Projects section v.4-->
     </div>
   </div>
 </div>
</section>

<section style="">
  <div class="container-fluid">
    <div class="row">
    <div class="col-sm-12 col-lg-12 col-md-12 mx-auto" id="thirteen_animate">
    <div class="card">
      <div class="row">


        <div class="col-lg-4 col-sm-6 col-md-4 mt-3 mx-auto" id="seventeen_animate">
         <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];  
            
      ?>
      <!-- Card group -->
<div class="card-group z-depth-0">
 <!-- Card -->
  <div class="card mb-4 z-depth-0">
    <!-- Card image -->
    <div class="view overlay">
      <img class="card-img-top" 
      src="include/img_3/<?php echo $image; ?>" alt="Card image cap" style="height: 280px;">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!-- Card content -->
    <div class="card-body">
      <!-- Title -->
      <span class="badge badge-danger"><?php echo $category; ?></span>
      <h5 class="card-title" id="title" style="
             color:#004d4d;
             text-transform: uppercase;
      "><a href="#"><?php echo $title; ?></a></h5>
      <!-- Text -->
      <p class="card-text font-weight-bold">
       <?php if(strlen($desc)>25) { echo (substr($desc, 0,120))."........"; } ?></p>
      <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
    </div>
    <!-- Card content -->
  </div>
  <!-- Card --> 
</div>
<div class="row mt-2">
 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];        
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0 mb-lg-0 mb-4 ml-2">
        <img class="img-fluid" src="include/img_3/<?php  echo $image; ?>" alt="Sample image" style="height:100px;width:100%;">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
      <h6 href="#" class="font-weight-bold mt-2"
      " id="title">
      <a>
      <?php echo $title; ?></a></h6>
      <p style="color:grey;">5 hour</p>
      <!-- Post data -->
    </div>
    <!-- Grid column -->
    <?php } ?>
  </div>
    </div>
    <!-- Grid column -->
 
<!-- Card group -->

  <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
        <div class="col-lg-4 col-sm-6 col-md-4 mt-3" id="fourteen_animate">
      <!-- Card group -->
<div class="card-group z-depth-0">
 <!-- Card -->
  <div class="card mb-4 z-depth-0">
    <!-- Card image -->
    <div class="view overlay">
      <img class="card-img-top" src="
      include/img_1/<?php echo $img; ?>" alt="Card image cap" style="height:280px;">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!-- Card content -->
    <div class="card-body">
      <!-- Title -->
      <span class="badge badge-success"><?php echo $category; ?></span>
          
      <h6  class="text- mt-2"
       id="title">
      <a href="#">
      <?php echo $title; ?></a></h6>
      <!-- Text -->
      <p class="card-text font-weight-bold">
      <?php if(strlen($desc)>25) { echo (substr($desc, 0,120))."........"; } ?></p>
      <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
    </div>
    <!-- Card content -->
  </div>
  <!-- Card --> 
</div>
<div class="row mt-2">
 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0 mb-lg-0 mb-4 ml-2">
        <img class="img-fluid" src="include/img_1/<?php echo $img; ?>" alt="Sample image" style="height:100px;width:100%;">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>
    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
          
      <h6 href="#" class="font-weight-bold mt-2"
      " id="title">
      <a>
      <?php echo $title; ?></a></h6>
      <p style="color:grey">5 hour</p>
      <!-- Post data -->
    </div>
    <?php } ?>
    <!-- Grid column -->
  </div>

  
<!-- Card group -->

      </div>  
       <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];    

                
      ?>

        <div class="col-lg-4 col-sm-6 col-md-4 mt-3" id="sixteen_animate">
      <!-- Card group -->
<div class="card-group z-depth-0">
 <!-- Card -->
  <div class="card mb-4 z-depth-0">
    <!-- Card image -->
    <div class="view overlay">
      <img class="card-img-top" src="include/img_3/<?php echo $image; ?>" alt="Card image cap" style="height:280px;">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!-- Card content -->
    <div class="card-body">
      <!-- Title -->
      <span class="badge badge-warning"><?php echo $category; ?></span>
      <h5 class="card-title" id="title" style="

             text-transform: uppercase;
      "><a href="#"><?php echo $title; ?></a></h5>
      <!-- Text -->
      <p class="card-text font-weight-bold">
      <?php if(strlen($desc)>25) { echo (substr($desc, 0,120))."........"; } ?></p>
      <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
    </div>
    <!-- Card content -->
  </div>
  <!-- Card --> 
</div>
<div class="row mt-2">
 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];    

                
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0 mb-lg-0 mb-4 ml-2">
        <img class="img-fluid z-depth-2" src="include/img_3/<?php echo $image; ?>" alt="Sample image" style="height:100px;width:100%;">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
      <h6 id="title"><a href="#" class="text- mt-1" style="font-weight: bold;
          
          
      "><?php echo $title; ?></a></h6>
      <p style="color:grey">5 hour</p>
      <!-- Post data -->
    </div>
    <hr>
    <!-- Grid column -->
    <?php } ?>
  </div>

  </div>
<!-- Card group -->

      </div>  
      <!--child row-->
      </div>
      </div>
    </div><!--parent col-->
    </div>
  </div>
</section>

<section class="mt-2 text-center pb-2" style="background:#ebebe0;">
 <h1 href="#" class="text-center" style="font-weight: bold;font-size: 30px;">
 <span class="badge badge-danger">OPINIONS </span>
 </h1>  
   <div class="container">
     <div class="row">
       <div class="col-sm-12 col-lg-12 col-md-12 mx-auto mt-3 ">
         
           <div class="row">
             <div class="col-sm-10 col-lg-4 col-md-6">
               <div class="card">
               <div class="card-header" style="background: white;">
                 <h2 ><span class="badge badge-success">Technology</span></h2>
               </div>
                <div class="card-body">
                 
                 <div class="row mt-2">
                 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];    

                
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0  mb-3 ml-1">
        <img class="img-fluid" src="
       include/img_3/<?php echo $image; ?>" alt="Sample image" style="height:100px;width:100%;">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
       <h6 id="title"><a href="#" class="text- mt-1" style="font-weight: bold;
      "><?php echo $title; ?></a></h6>
      <p style="color:grey">5 hour</p>
      <!-- Post data -->
    </div>
    <!-- Grid column -->
    <?php } ?>
  </div>
   </div><!--card-body-->
             </div>
           </div>

             <div class="col-sm-10 col-lg-4 col-md-6">
               <div class="card">
            <div class="card-header" style="background: white;">
                 <h3 ><span class="badge badge-success">History</span></h3>
               </div>
               <div class="card-body">
                 
                 <div class="row mt-2">
                 <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0  mb-1 ml-1">
        <img class="img-fluid" src="
       include/img_1/<?php echo $img; ?>" alt="Sample image" style="height:100px;width: 100%;">
      </div>

    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
      <h6 id="title"><a href="#" class="text- mt-1" style="font-weight: bold;
          
          
      "><?php echo $title; ?></a></h6>
      <p style="color:grey">5 hour</p>
      <!-- Post data -->
    </div>
    <!-- Grid column -->
    <?php } ?>
  </div>

               </div><!--card-body-->
             </div>
           </div>

             <div class="col-sm-10 col-lg-4 col-md-6">
               <div class="card">
                <div class="card-header" style="background: white;">
                 <h3>
               <span class="badge badge-success">Sports</span></h3>
               </div>
                <div class="card-body">
                
                 <div class="row mt-2">
                   <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-0  mb-3 ml-1">
        <img class="img-fluid" src="
        include/img_1/<?php echo $img; ?>" alt="Sample image" style="height: 100px;width: 100%:">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->
    <!-- Grid column -->
    <div class="col-lg-7">
     
     <h6 id="title"><a href="#" class="text- mt-1" style="font-weight: bold;
          
          
      "><?php echo $title; ?></a></h6>
      <p style="color:grey">5 hour</p>
      <!-- Post data -->
    </div>
    <!-- Grid column -->
    <?php } ?>
  </div>

               </div><!--card-body-->
             </div>
           </div>

         </div><!--child row-->
       </div>
     </div><!---row -->
   </div>
</section>
<section class="mt-4 mb-4" style="background: #f9ecec;">
<h1 style="text-transform: uppercase;font-size: 30px;font-weight: bold;font-family:Castellar;" id="brand" class="text-center">
<span class="badge badge-danger">Entertainment</span></h1>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-sm-12 col-md-12">
        <div class="row">
           <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,1";
        $finding=mysqli_query($con,$find);
         $data=mysqli_fetch_array($finding);
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
            <div class="col-lg-5 col-sm-10 col-md-6 mt-3   mx-auto" style="">
      <!-- Card group -->
<div class="card-group ">
 <!-- Card -->
  <div class="card mb-4 z-depth-0">
    <!-- Card image -->
    <div class="view overlay">
      <img class="card-img-top" src="
      include/img_1/<?php echo $img; ?>" alt="Card image cap" style="height: 250px;width:100%;">
      <a href="#!">
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!-- Card content -->
    <div class="card-body">
      <!-- Title -->
      <span class="badge badge-danger"><?php echo $category; ?></span>
      <h6 class="card-title" id="title" style="
             
             text-transform: uppercase;
      "><a href="#"><?php echo $title; ?></a></h6>
      <!-- Text -->
      <p class="card-text font-weight-bold">
        <?php if(strlen($desc)>25) { echo (substr($desc, 0,140))."........"; } ?></p>
      </p>
      <!-- Provides extra visual weight and identifies the primary action in a set of buttons -->
    </div>
    <!-- Card content -->
  </div>
  <!-- Card --> 
</div>
 </div>
 <div class="col-lg-7 col-sm-10 col-md-6 mx-auto">
   <div class="row">
   <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_3_img order by rand() limit 0,2";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
              $title=$data["p_title"];
              $category=$data["p_category"];
              $desc=$data["p_desc1"];
              $image=$data["p_img1"];    

                
      ?>
     <div class="col-sm-10 col-lg-6 col-md-10 mx-auto mt-3 mb-5">   <!-- Card -->
<div class="card z-depth-0">
  <!-- Card image -->
  <img class="card-img-top" src="
  include/img_3/<?php echo $image; ?>" alt="Card image cap" style="height:200px;width:100%;">
  <!-- Card content -->
  <div class="card-body">
    <!-- Title -->
    <p class="badge badge-danger"><?php echo $category; ?></p> 
    <h6 class="card-title" id="title"><a><?php echo $title; ?></a></h6>
    <!-- Text -->
    <p class="card-text">
     <?php if(strlen($desc)>25) { echo (substr($desc, 0,140))."........"; } ?></p>
    <!-- Button -->
    
  </div>
</div>
<!-- Card -->
     </div>
     <?php } ?>
   </div><!--secchild-->
 </div>
 
 <!--secondgrid-->

      </div><!--grid-->
    </div>


    <!--row-->
     <?php 
        $con=mysqli_connect("localhost","root","","writewing");
        $find="SELECT * FROM english_1_img order by rand() limit 0,4";
        $finding=mysqli_query($con,$find);
         while($data=mysqli_fetch_array($finding)){
            $title=$data["title"];
            $skill=$data["skill"];
            $img=$data["p_img"];
            $desc=$data["p_desc"];
            $id=$data["id"];
            $category=$data["category"];
      ?>
    <div class="col-lg-3 col-sm-6 col-md-4 mb-5" style="max-height:80px;min-height:80px;width: 50px !important;">
   <div class="card z-depth-0">
  <!-- Card image -->
  <img class="card-img-top" src="
  include/img_1/<?php echo $img; ?>" alt="Card image cap" style="max-height:80px;width:100%;">
  <!-- Card content -->
  <div class="card-body">
  <h6 id="title">
    <a href="#"><?php echo $title; ?></a>
  </h6>
    
    <!-- Button -->
   
  </div>

</div>
 </div>
 <?php } ?>
 <!--5 grid-->
  </div>
  </div>
</section>
<section class="mt-5 mb-3">
  <div class="container ">
    <div class="row">
      <div class="col-sm-10 col-lg-12 col-md-10 mx-auto mt-5">
      <div class="card">
    <div class="row">

      <div class="col-md-6 mt-3">

        <div class="d-flex flex-column justify-content-center align-items-center h-100">
          <h1 class="heading display-3"  id="brand" style="font-weight: bold;">
          Write Wing</h1>
          <p class="font-weight-bold text-center" style=" 
          text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);
             color:#1a000a;">
          Hii this is Write wing on Online News Portal website 
          We are providing some good social stuffs Which
           can definitely help you to get some knowledge
         </p>
         <h3 class="font-weight-bold" style="text-transform: uppercase;">Support Us</h3>
          <div class="mr-auto  text-center mx-auto">
            <button type="button" class="btn btn-danger btn-sm  btn-rounded"> 
            <i class="fas fa-rupee-sign"></i>&nbsp; 50</button>
             <button type="button" class="btn btn-danger btn-sm btn-rounded"> <i class="fas fa-rupee-sign"></i>&nbsp;100</button>
              <button type="button" class="btn btn-info btn-sm btn-rounded"> <i class="fas fa-rupee-sign"></i>&nbsp;200</button>
               <button type="button" class="btn btn-success btn-sm btn-rounded"> <i class="fas fa-rupee-sign"></i>&nbsp;500</button>
                <button type="button" class="btn btn-success btn-sm btn-rounded"> <i class="fas fa-rupee-sign"></i>&nbsp;1000</button>
                 <button type="button" class="btn btn-success btn-sm btn-rounded"> <i class="fas fa-rupee-sign"></i>&nbsp;2000</button>
          </div>
        </div>

      </div>

      <div class="col-md-6">

        <div class="view">
          <img src="
          include/media/p1.jpg" class="img-fluid" alt="smaple image">
          <div class="mask flex-center hm-gradient">
          </div>
        </div>

      </div>

    </div>

  </section>
  <!-- Intro -->


<!-- Main navigation -->
      </div>
    </div><!--row -->
  </div><!--container -->
</section>
<section>
  <div class="container" style="background: #ffcc99;">
    <div class="row">
      <div class="col-md-10 col-lg-12 col-sm-10 mx-auto">
        <!-- Section: Blog v.1 -->
<section class="my-5">

  <!-- Section heading -->
  <h2 class="h1-responsive font-weight-bold text-center my-5 text-info" style="font-family:Castellar;">IN SIGHT</h2>
  <hr>
  <!-- Section description -->
 
  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-lg-0 mb-4">
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/img%20(27).jpg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7">

      <!-- Category -->
      <a href="#!" class="green-text">
        <h6 class="font-weight-bold mb-3"><i class="fas fa-utensils pr-2"></i>Food</h6>
      </a>
      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>Title of the news</strong></h3>
      <!-- Excerpt -->
      <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime
        placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus et aut officiis debitis.</p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 19/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-success btn-md">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-7">

      <!-- Category -->
      <a href="#!" class="pink-text">
        <h6 class="font-weight-bold mb-3"><i class="fas fa-image pr-2"></i>Lifestyle</h6>
      </a>
      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>Title of the news</strong></h3>
      <!-- Excerpt -->
      <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum
        deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non
        provident.</p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 14/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-pink btn-md mb-lg-0 mb-4">Read more</a>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2">
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/img%20(34).jpg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

  <hr class="my-5">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-5">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-lg-0 mb-4">
        <img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/img (28).jpg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-7">

      <!-- Category -->
      <a href="#!" class="indigo-text">
        <h6 class="font-weight-bold mb-3"><i class="fas fa-suitcase pr-2"></i>Travels</h6>
      </a>
      <!-- Post title -->
      <h3 class="font-weight-bold mb-3"><strong>Title of the news</strong></h3>
      <!-- Excerpt -->
      <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur
        magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro qui dolorem ipsum quia sit amet.</p>
      <!-- Post data -->
      <p>by <a><strong>Carine Fox</strong></a>, 11/08/2018</p>
      <!-- Read more button -->
      <a class="btn btn-indigo btn-md">Read more</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Blog v.1 -->

      </div>
    </div><!-- row -->
  </div><!--container -->
</section>
<hr>
<section>
  <div class="container" style="background: #ccffcc;">
    <div class="row">
      <div class="col-md-10 col-lg-12 col-sm-10 mx-auto">
        <!-- Section heading -->
<h2 class="h1-responsive font-weight-bold my-5 text-success text-center my-3 " 
   style="border-left: 10px solid red; width:300px;height: 50px;">Our best Choice</h2>
<!-- Section description -->
<!-- Grid row -->
<div class="row d-flex justify-content-center">

  <!-- Grid column -->
  <div class="col-md-6 col-xl-5 mb-4">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-2">
      <img src="https://mdbootstrap.com/img/Photos/Others/laptop-sm.jpg" class="img-fluid" alt="Sample project image">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="green-text">
        <h5 class="font-weight-bold mt-2 mb-3"><i class="fas fa-chart-line pr-2"></i>Marketing</h5>
      </a>
      <h4 class="font-weight-bold mb-3">Title of the news</h4>
      <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit cupidatat
        proident voluptatem quia numquam.</p>
      <a class="btn btn-success btn-rounded btn-md"> View more</a>
    </div>
  </div>
  <!-- Grid column -->

  <!-- Grid column -->
  <div class="col-md-6 col-xl-5 mb-4">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-2">
      <img src="https://mdbootstrap.com/img/Photos/Others/images/19.jpg" class="img-fluid" alt="Sample project image">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body">
      <a href="" class="blue-text">
        <h5 class="font-weight-bold mt-2 mb-3"><i class="fas fa-eye pr-2"></i>Entertainment</h5>
      </a>
      <h4 class="font-weight-bold mb-3">Title of the news</h4>
      <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam nisi ut
        aliquid, aspernatur aut odit aut fugit.</p>
      <a class="btn btn-success btn-rounded btn-md"> View more</a>
    </div>
  </div>
  <!-- Grid column -->

</div>
<!-- Grid row -->

<!-- Grid row -->
<div class="row d-flex justify-content-center">

  <!-- Grid column -->
  <div class="col-md-6 col-xl-5 mb-md-0 mb-4">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-2">
      <img src="https://mdbootstrap.com/img/Photos/Others/images/48.jpg" class="img-fluid" alt="Sample project image">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body pb-md-0">
      <a href="" class="brown-text">
        <h5 class="font-weight-bold mt-2 mb-3"><i class="fas fa-camera pr-2"></i>Travel</h5>
      </a>
      <h4 class="font-weight-bold mb-3">Title of the news</h4>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium,
        totam rem aperiam, eaque ipsa.
      </p>
      <a class="btn btn-success btn-rounded btn-md"> View more</a>
    </div>
  </div>
  <!-- Grid column -->

  <!-- Grid column -->
  <div class="col-md-6 col-xl-5">
    <!--Featured image-->
    <div class="view overlay rounded z-depth-2">
      <img src="https://mdbootstrap.com/img/Photos/Horizontal/E-commerce/Products/img (56).jpg" class="img-fluid"
        alt="Sample project image">
      <a>
        <div class="mask rgba-white-slight"></div>
      </a>
    </div>
    <!--Excerpt-->
    <div class="card-body pb-0">
      <a href="" class="cyan-text">
        <h5 class="font-weight-bold mt-2 mb-3"><i class="fas fa-phone pr-2"></i>Technology</h5>
      </a>
      <h4 class="font-weight-bold mb-3">Title of the news</h4>
      <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur,
        illum qui dolorem eum fugiat quo voluptas.</p>
      <a class="btn btn-success btn-rounded btn-md"> View more</a>
    </div>
  </div>
  <!-- Grid column -->

</div>
<!-- Grid row -->
      </div>
    </div><!--row -->
  </div><!-- container -->
</section>
</body>
  <!--/.Double navigation-->

  <!--Main Layout-->
  
  <!--Main Layout-->
<footer>
  <?php include("include/footer.php"); ?>
</footer>
</body>
  <!--Main Layout-->


<!--Main Navigation-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
  <script type="text/javascript">
    // MDB Lightbox Init
$(function () {
$("#mdb-lightbox-ui").load("mdb-addons/mdb-lightbox-ui.html");
});
  </script>
  <script type="text/javascript">
  /*
    $(document).ready(function(){
      $(window).scroll(function(){
        var positiontop=$(document).scrollTop();
        console.log(positiontop);
         if((positiontop>0) && (positiontop<240)){
          $("#top_10").addClass("animated fadeInLeft");

        }
        if((positiontop>240) && (positiontop<400)){
          $("#first_animate").addClass("animated fadeInLeft");

        }
         if((positiontop>400) && (positiontop<700)){
          $("#animate_second").addClass("animated fadeInRightBig");

        }
         if((positiontop>900) && (positiontop<1300)){
          $("#third_animate").addClass("animated rotateInUpLeft");

        }
        if((positiontop>900) && (positiontop<1300)){
          $("#fourth_animate").addClass("animated rotateInDownRight");

        }
        if((positiontop>900) && (positiontop<1300)){
          $("#fifth_animate").addClass("animated rotateInDownLeft");

        }
        if((positiontop>1400) && (positiontop<2100)){
          $("#sixth_animate").addClass("animated flipInX");

        }
        if((positiontop>1400) && (positiontop<2100)){
          $("#seventh_animate").addClass("animated lightSpeedIn");

        }
        if((positiontop>2500) && (positiontop<3300)){
          $("#eighth_animate").addClass("animated flipInX");

        }
        if((positiontop>4000) && (positiontop<4500)){
          $("#ninth_animate").addClass("animated swing");

        }
         if((positiontop>4200) && (positiontop<4600)){
          $("#tenth_animate").addClass("animated jackInTheBox");

        }
         if((positiontop>4200) && (positiontop<4600)){
          $("#eleventh_animate").addClass("animated heartBeat");

        }
        if((positiontop>4900) && (positiontop<5500)){
          $("#thirteen_animate").addClass("animated fadeInDownBig");

        }
        if((positiontop>4900) && (positiontop<5500)){
          $("#thirteen_animate").addClass("animated fadeInDownBig");

        }
        if((positiontop>5500) && (positiontop<6000)){
          $("#fourteen_animate").addClass("animated zoomInDown");

        }
        if((positiontop>5500) && (positiontop<6000)){
          $("#sixteen_animate").addClass("animated zoomInDown");

        }
         if((positiontop>5500) && (positiontop<6000)){
          $("#seventeen_animate").addClass("animated slideInDown");

        }
      })
    })*/

  </script>
  <script type="text/javascript">
    // SideNav Button Initialization
$(".button-collapse").sideNav();
// SideNav Scrollbar Initialization
var sideNavScrollbar = document.querySelector('.custom-scrollbar');
var ps = new PerfectScrollbar(sideNavScrollbar);
  </script>
</body>

</html>
